package com.railse.hiring.workforcemgmt.model.enums;

public enum TaskLogType {
    PRIORITY_UPDATED,
    STATUS_UPDATED,
    TASK_CREATED,
    COMMENTS_ADDED;

}
